<?php
	$text=file_get_contents('C:/leadnext/hist.txt');
	$keywords= array("Gaming"=> array("Gaming","game","gaming","games"),
					"Ultraslim"=> array("Ultraslim","ultraslim","portable","travel"),
					"Programming"=> array("Programming","program","programming language","code"),
					"Mainstream"=> array("Mainstream","laptops","laptop"),
					"Convertables"=>array("Convertables","tablets"));
	$tagged= array();
	foreach ($keywords as $a) {
		foreach($a as $b){
			$pos=strpos($text,$b);
			if($pos!=FALSE){
				// echo "$a[0]\n";
				if(array_search($a[0],$tagged)===FALSE){
					print("not found");
					array_push($tagged,$a[0]);

				}
				}
			}
		
		}
	print_r($tagged);
?>