<?php
$connection = @new mysqli('localhost', 'me', 'leadnext','leadnext');
if (!$connection){
    die("Database Connection Failed" . mysqli_error($connection));
}
$select_db = mysqli_select_db($connection, 'leadnext');
if (!$select_db){
    die("Database Selection Failed" . mysqli_error($connection));
}