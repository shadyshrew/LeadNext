<!DOCTYPE html>
<html lang="en">
<?php
    
?>
<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="pro.css">

</head>
<body>

  
    <div class="navbar-collapse collapse inverse" id="navbar-header">
        <div class="container-fluid">
            <div class="about">
                <h4>About</h4>
                <p class="text-muted">We are students of Sir M. Visvesvaraya Institute of technology and we came up with an idea based on the inadequacies we saw in the online marketplace the issues that prospective buyers faced.</p>
            </div>
            <div class="social">
                <h4>Contact</h4>
                <ul class="list-unstyled">
                    <li><a href="#">Like on Facebook</a></li>
                    <li>Email us: leadnext2018@gmail.com</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="navbar navbar-static-top navbar-dark bg-inverse">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-header">
            &#9776;
            </button>
            <a href="#" class="navbar-brand">LeadNext</a>
            <a class="btn btn-primary nav navbar-nav pull-sm-right" href="logout.php"><center>Logout</center></a>
        </div>
    </div>


    <section class="jumbotron text-xs-center">
        <div class="container">
            <h1 class="jumbotron-heading">Welcome</h1>
            <p class="lead text-muted">Get started! You'll find your personlaised suggestions below!</p>
            <div>
                <a href="index.html" class="btn btn-info">Back to Home page</a>
            </div>
            <br>
                    
                    <a href="#shop" class="btn btn-secondary-outline btn-sm" role="button">&darr;</a>
        </div>
    </section>

    <div id="shop" class="album text-muted">
        <div class="container">
        <div class="row">
            <?php
            $conn = new mysqli("localhost", "me", "leadnext", "laptops");
            $cat = $_GET['cat'];
            $cat = mysqli_real_escape_string($conn,$cat);
            // Check connection
            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
             } 
            $sql = "SELECT model,type,comp_name,link,price,model_des FROM laptops,comp_details WHERE type LIKE '$cat' AND comp_id = cid";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc()) { ?>
             <div class="card">
                    <img src="laptops/<?php echo $row["model"];?>.jpg" alt="shreyas">
                    <p class="card-text"><h6><strong>Name:</strong><?php echo $row["model"] ?> <br/>
                    <strong>Product Category:</strong><?php echo $row["type"] ?> <br/>
                    <strong>Seller:</strong> <?php echo $row["comp_name"] ?><br/>
                    <strong>Price:</strong><?php echo $row["price"] ?><br/>
                    <strong>Product Description:</strong><?php echo $row["model_des"] ?></h6>
                    <a href = "<?php echo $row["link"]; ?>">BUY NOW!</a></p>
            </div>

            <?php } ?>
            

                
            </div>

        </div>
    </div>
    
    </div>
        </div>
    </div>

     <hr>
                        
                        

    <footer class="text-muted">
        <div class="container">
            <p class="pull-xs-right">
                <a href="#">Back to top</a>
            </p>
            <p>Thank you for visiting us, contact us for any queries.</p>
        </div>
    </footer>
   
   
    <!-- jQuery first, then Bootstrap JS. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>