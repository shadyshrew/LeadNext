<?php

?>
<style type="text/css">
	form, a{
		margin-top: 325px;
		margin-left: 520px;
	}
</style>
<form method = "POST" enctype="multipart/form-data" action="upload.php">
	<input type="file" name="file">
	<input type="submit" value="Upload">
</form>


<?php
$dir    = 'uploads';
$files1 = scandir($dir);
$files2 = scandir($dir, 1);

for ($i=2; $i< count($files1) ; $i++) { 
	?>
	<p>
	<a download="<?php echo $files1[$i] ?>" href="uploads/<?php echo $files1[$i] ?>"><?php echo $files1[$i] ?></a>
	</p>
<?php
}
?>
