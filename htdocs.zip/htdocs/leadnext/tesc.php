<?php
	echo exec('history.py');
?>