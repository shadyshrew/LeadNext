<!DOCTYPE html>
<html lang="en">
<?php
    $text=file_get_contents('C:/leadnext/hist.txt');
    $keywords= array("Gaming"=> array("Gaming","game","gaming","games"),
                    "Ultraportable"=> array("Ultraportable","ultraslim","portable","travel"),
                    "Programming"=> array("Programming","program","programming language","code"),
                    "Mainstream"=> array("Mainstream","laptops","laptop"),
                    "Convertables"=>array("Convertables","tablets"));
    $tagged= array();
    foreach ($keywords as $a) {
        foreach($a as $b){
            $pos=strpos($text,$b);
            if($pos!=FALSE){
                // echo "$a[0]\n";
                if(array_search($a[0],$tagged)===FALSE){
                    array_push($tagged,$a[0]);

                }
                }
            }
        
        }
?>
<head>
    <!-- Required meta tags always come first -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="buttons.css">

</head>
<body>

  
    <div class="navbar-collapse collapse inverse" id="navbar-header">
        <div class="container-fluid">
            <div class="about">
                <h4>About</h4>
                <p class="text-muted">We are students of Sir M. Visvesvaraya Institute of technology and we came up with an idea based on the inadequacies we saw in the online marketplace the issues that prospective buyers faced.</p>
            </div>
            <div class="social">
                <h4>Contact</h4>
                <ul class="list-unstyled">
                    <li><a href="#">Like on Facebook</a></li>
                    <li>Email us: leadnext2018@gmail.com</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="navbar navbar-static-top navbar-dark bg-inverse">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-header">
            &#9776;
            </button>
            <a href="#" class="navbar-brand">The LeadNext Team</a>
        </div>
    </div>

    <section class="jumbotron text-xs-center">
        <div class="container">
            <h1 class="jumbotron-heading">Choose</h1>
            <p class="lead text-muted">From your iterests, you might be looking for the following.</p>
            <div>
                <a href="index.html" class="btn btn-info">Back to Home page</a>
            </div>
        </div>
    </section>

    <div class="album text-muted">
        <div class="container">
        <div class="row">
            <?php foreach ($tagged as $key => $value) { ?>
                
            <a href=pro.php?cat=<?php echo $value; ?> >
                <div class="card">
                    <img src="img/<?php echo $value; ?>.jpg" alt="shreyas">
                    <p class="card-text"><h1><?php echo $value; ?></h1> </p>
                </div>
            </a>
            <?php  } ?>
            </div>

        </div>
    </div>

    <footer class="text-muted">
        <div class="container">
            <p class="pull-xs-right">
                <a href="#">Back to top</a>
            </p>
            <p>Thank you for visiting us, contact us for any queries.</p>
        </div>
    </footer>
   
   
    <!-- jQuery first, then Bootstrap JS. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>