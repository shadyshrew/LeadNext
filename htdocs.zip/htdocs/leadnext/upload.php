<?php
	$file = $_FILES["file"];
	move_uploaded_file($file["tmp_name"], "uploads/" . "1.pdf");
	header("Location: up.php");
?>


