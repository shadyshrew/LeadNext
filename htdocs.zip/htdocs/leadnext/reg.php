<?php 
if(isset($_POST['submit'])){
   $username = $_POST['username'];
   $password = $_POST['password'];
   $email = $_POST['email'];
    $connection = @new mysqli('localhost', 'me','leadnext','leadnext');
    if(!$connection){
    die("Database connection failed");
    }
    $query = "INSERT INTO registered(name,password,email)";
    $query .= "VALUES ('$username', '$password' , '$email')";
    $result = mysqli_query($connection, $query);
    if(!$result){
    die('query is faild' . mysqli_connect_error());
    }
    header('Location: index.html');
}
?>