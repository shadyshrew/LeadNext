<?php 
 $fn = './up.php';    
 $newfn = './test2.php'; 
 copy($fn,$newfn);
 header("Location: startup.html");
?>